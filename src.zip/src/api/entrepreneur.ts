import { apiClient } from "./index";

// --- Interfaces matching your Mongoose schema ---

export interface TeamMember {
  name: string;
  role: string;
  avatar: string;
  linkedin: string;
}

export interface StartupOverview {
  problemStatement: string;
  solution: string;
  marketOpportunity: string;
  competitiveAdvantage: string;
}

export interface Startup {
  _id: string;
  entrepreneurId: string;
  startupName: string;
  location: string;
  foundedAt: string; 
  totalFunds: number;
  industry: string;
  overview: StartupOverview;
  team: TeamMember[];
  createdAt: string;
  updatedAt: string;
}

export interface UserInfo {
  _id: string;
  name: string;
  email: string;
  avatar: string;
  isOnline: boolean;
  role: string;
  location?: string;
  isEmailVerified: boolean;
}


export interface EntrepreneurCardData {
  id: string;
  name: string;
  avatarUrl: string;
  isOnline: boolean;
  startupName: string | null;
  industry: string | null;
  location: string | null;
  foundedYear: number | null;
  pitchSummary: string | null;
  fundingNeeded: number;
  totalFunds: number;
  teamSize: number;
}


export interface StartupAndUserResponse {
  success: boolean;
  data: {
    user: UserInfo | null;
    startup: Startup | null;
  };
  error?: string;
}

//  Get startup profile + user details by entrepreneur userId

export const getStartupByUserId = async (id: string): 
Promise<StartupAndUserResponse> => {
  try {
    const res = await apiClient.get<StartupAndUserResponse>(`/entrepreneur/startup/${id}`);
    return res.data;
  } catch (error: any) {
    console.error("Error fetching startup:", error);
    return { success: false, data: { user: null, startup: null }, error: error.message || "Failed to fetch startup" };
  }
};


//  Create a new startup
export const createStartup = async (startupData: Partial<Startup>): 
Promise<{ success: boolean; data: Startup | null; error?: string }> => {
  try {
    const res = await apiClient.post<{ success: boolean; data: Startup }>(
      "/entrepreneur/createStartup",
      startupData
    );
    return res.data;
  } catch (error: any) {
    console.error("Error creating startup:", error);
    return { success: false, data: null, error: error.message || "Failed to create startup" };
  }
};


  // Update existing startup by startup ID
export const updateStartup = async (id: string, startupData: Partial<Startup>):
 Promise<{ success: boolean; data: Startup | null; error?: string }> => {
  try {
    const res = await apiClient.put<{ success: boolean; data: Startup }>(
      `/entrepreneur/startup/${id}`,
      startupData
    );
    return res.data;
  } catch (error: any) {
    console.error("Error updating startup:", error);
    return { success: false, data: null, error: error.message || "Failed to update startup" };
  }
};


export const getAllEntrepreneurs = async (): 
Promise<{ success: boolean; entrepreneurs: EntrepreneurCardData[] }> => {
  try {
    const res = await apiClient.get<{ success: boolean; entrepreneurs: EntrepreneurCardData[] }>(
      "/entrepreneur/all"
    );
    return res.data;
  } catch (error: any) {
    console.error("Error fetching entrepreneurs:", error);
    return { success: false, entrepreneurs: [] };
  }
};

// Search Startups
export const searchEntrepreneursAPI = async (params: {
  searchQuery?: string;
  industries?: string[];
  fundingRanges?: string[];
  locations?: string[];
}): Promise<{ success: boolean; results: EntrepreneurCardData[] }> => {
  try {
    const res = await apiClient.get<{ success: boolean; results: EntrepreneurCardData[] }>(
      "/entrepreneur/search",
      { params }
    );
    return res.data;
  } catch (error: any) {
    console.error("Error searching entrepreneurs:", error);
    return { success: false, results: [] };
  }
};


