// frontend/services/authService.ts
import { apiClient, publicApi } from "../api/index"; 
import { UserRole } from "../types";

    export interface RegisterRequest {
      name: string;
      email: string;
      password: string;
      role: UserRole;
    }

    export interface SignInRequest {
      email: string;
      password: string;
    }

    export interface RegisterResponse {
      message: string;
      id: string;
      email: string;
    }

    export interface SignInResponse {
      message: string;
      user: {
        id: String;
        name: string;
        email: string;
        role: UserRole;
        bio?: string;
        avatar?: string;
        location?: string;
        isOnline: boolean;
      };
      accessToken: string;
    }

    export interface VerifyEmailRequest {
      id: string;
      email: string;
      verificationCode: string;
    }

    export interface VerifyEmailResponse {
      message: string;
      user: {
        id: String;
        name: string;
        email: string;
        role: UserRole;
        bio?: string;
        avatar?: string;
        location?: string;
        isOnline: boolean;
      };
      accessToken: string;
    }

    export interface ApiResponse<T = any> {
      success?: boolean;  
      message: string;
      data?: T;
    }

    export interface User {
      id: string;
      name: string;
      email: string;
      role: "investor" | "entrepreneur";
    }

    export const registerUser = async (
      data: RegisterRequest
    ): Promise<RegisterResponse> => {
      try {
        const response = await publicApi.post<RegisterResponse>("/auth/register", data);
        return response.data; 
      } catch (error: any) {
        const message = error.response?.data?.error || "Something went wrong";
        throw new Error(message);
      }
    };

    export const signInUser = async (
      data: SignInRequest
    ): Promise<SignInResponse> => {
      try {
        const response = await publicApi.post<SignInResponse>("/auth/signin", data, {
          withCredentials: true, 
        });
        return response.data;
      } catch (error: any) {
        const message = error.response?.data?.error || "Something went wrong";
        throw new Error(message);
      }
    };
    

    export const verifyEmail = async (
      data: VerifyEmailRequest
    ): Promise<VerifyEmailResponse> => {
      try {
        const response = await publicApi.post<VerifyEmailResponse>("/auth/verify-email",
          data
        );
        return response.data;
      } catch (error: any) {
        const message = error.response?.data?.error || "Something went wrong";
        throw new Error(message);
      }
    };

    export const logoutUser = async (): Promise<{ message: string }> => {
       try {
         const response = await apiClient.post<{ message: string }>(
           "/auth/logout",
           {} 
         );
         return response.data;
       } catch (error: any) {
         const message = error.response?.data?.error || "Something went wrong during logout";
         throw new Error(message);
       }
    };
