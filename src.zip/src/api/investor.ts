import { apiClient } from "./index";

  /* ----------------------------- INVESTOR TYPES ----------------------------- */
  export interface InvestorUser {
    id: string;
    name: string;
    email: string;
    role: "investor";
    bio: string;
    isEmailVerified: boolean;
    avatar: string;
    isOnline: boolean;
    lastActiveAt: string | null;
    location: string;
    industries: string[];
    investmentStages: string[];
    investmentCriteria: string[];
    totalInvestments: number;
    investmentRange: {
      min: number | null;
      max: number | null;
    };
    portfolioCompanies: string[];
  }

  export interface Investor {
    id: string;
    name: string;
    isOnline: boolean;
    avatarUrl: string;
    bio: string;
    totalInvestments: number;
    investmentStage: string[];
    investmentInterests: string[];
    minimumInvestment: number;
    maximumInvestment: number;
  }

  /* ----------------------------- INVESTOR RESPONSES ----------------------------- */
  export interface GetInvestorProfileResponse {
    success: boolean;
    message: string;
    investor: InvestorUser;
  }

  export interface UpdateInvestorProfileResponse {
    success: boolean;
    message: string;
    investor: InvestorUser;
  }

  export interface GetRecommendedInvestorsResponse {
    success: boolean;
    count: number;
    data: Investor[];
  }

  export interface SearchInvestorsResponse {
    success: boolean;
    count: number;
    data: Investor[];
  }

  /* ----------------------------- INVESTOR API ----------------------------- */
  // Fetch logged-in investor’s profile
  export const getInvestorProfile = async (
    id: string
  ): Promise<GetInvestorProfileResponse> => {
    const { data } = await apiClient.get<GetInvestorProfileResponse>(
      `/investor/me/${id}`
    );
    return data;
  };

  export const updateInvestorProfile = async (
    id: string,
    payload: Partial<InvestorUser>
  ): Promise<UpdateInvestorProfileResponse> => {
    const { data } = await apiClient.patch<UpdateInvestorProfileResponse>(
      `/investor/update-specific-detials/${id}`,
      payload
    );
    return data;
  };

  export const getRecommendedInvestors =
    async (): Promise<GetRecommendedInvestorsResponse> => {
      const { data } =
        await apiClient.get<GetRecommendedInvestorsResponse>(
          "/investor/recommended-investors"
        );
      return data;
    };

  //  Search Investors
  export const searchInvestors = async (params: {
    searchQuery?: string;
    industries?: string[];
    stages?: string[];
    minInvestment?: number;
    maxInvestment?: number;
    location?: string;
  }): Promise<SearchInvestorsResponse> => {
    const query = new URLSearchParams();

    if (params.searchQuery) query.append("searchQuery", params.searchQuery);
    if (params.industries) query.append("industries", params.industries.join(","));
    if (params.stages) query.append("stages", params.stages.join(","));
    if (params.minInvestment)
      query.append("minInvestment", params.minInvestment.toString());
    if (params.maxInvestment)
      query.append("maxInvestment", params.maxInvestment.toString());
    if (params.location) query.append("location", params.location);

    const { data } = await apiClient.get<SearchInvestorsResponse>(
      `/investor/search?${query.toString()}`
    );
    return data;
  };

  /* ----------------------------- REQUEST TYPES ----------------------------- */
  export interface Request {
    _id: string;
    investorId: string;
    entrepreneurId: string;
    startupId: string;
    message: string;
    status: "pending" | "accepted" | "rejected" | "withdrawn";
    createdAt: string;
    updatedAt: string;
    respondedAt?: string | null;
  }

  export interface RequestResponse {
    success: boolean;
    message: string;
    data?: Request;
  }

  export interface RequestListResponse {
    success: boolean;
    count: number;
    data: Request[];
  }

  /* ----------------------------- REQUEST API ----------------------------- */
  // Investor sends request
// Investor sends request
export const sendRequest = async (
  investorId: string,
  entrepreneurId: string,
  startupId: string,
  message: string
): Promise<RequestResponse> => {
  const { data } = await apiClient.post<RequestResponse>("/requests/send", {
    investorId,      // now included
    entrepreneurId,
    startupId,
    message,
  });
  return data;
};

  // Entrepreneur responds (accept/reject)
  export const respondRequest = async (
    requestId: string,
    action: "accepted" | "rejected"
  ): Promise<RequestResponse> => {
    const { data } = await apiClient.put<RequestResponse>(
      `/requests/${requestId}/respond`,
      { action }
    );
    return data;
  };

  // Investor withdraws
  export const withdrawRequest = async (
    requestId: string
  ): Promise<RequestResponse> => {
    const { data } = await apiClient.put<RequestResponse>(
      `/requests/${requestId}/withdraw`
    );
    return data;
  };

  // Fetch entrepreneur’s incoming requests
  export const getEntrepreneurRequests = async (
    entrepreneurId: string
  ): Promise<RequestListResponse> => {
    const { data } = await apiClient.get<RequestListResponse>(
      `/requests/entrepreneur/${entrepreneurId}`
    );
    return data;
  };

  // Fetch investor’s sent requests
  export const getInvestorRequests = async (
    investorId: string
  ): Promise<RequestListResponse> => {
    const { data } = await apiClient.get<RequestListResponse>(
      `/requests/investor/${investorId}`
    );
    return data;
  };
